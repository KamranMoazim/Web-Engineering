﻿


namespace PassengerLib
{
    public class Passenger
    {
        public string? name { get; set; }
        public string? phoneNo { get; set; }

    }
}
