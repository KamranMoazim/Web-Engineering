﻿using System;

namespace VehicleLib
{
    public class Vehicle
    {
        public string? type { get; set; }

        public string? model { get; set; }

        public string? licensePlate { get; set; }


    }
}