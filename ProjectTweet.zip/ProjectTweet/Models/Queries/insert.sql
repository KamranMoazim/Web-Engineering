-- INSERT INTO MyDB.dbo.TweetUser (Username, Password) VALUES ('t@t.t', '123')
-- INSERT INTO MyDB.dbo.TweetUser (Username, Password) VALUES ('k@k.k', '456')




-- INSERT INTO MyDB.dbo.Tweet (Title, Content, PostedDate, UserId) VALUES ('Title 1', 'Content of Title 1', '2023-01-01', 1);
-- INSERT INTO MyDB.dbo.Tweet (Title, Content, PostedDate, UserId) VALUES ('Title 2', 'Content of Title 2', '2023-01-01', 1);
-- INSERT INTO MyDB.dbo.Tweet (Title, Content, PostedDate, UserId) VALUES ('Title 3', 'Content of Title 3', '2023-01-01', 1);
-- INSERT INTO MyDB.dbo.Tweet (Title, Content, PostedDate, UserId) VALUES ('Title 4', 'Content of Title 4', '2023-01-01', 1);

-- INSERT INTO MyDB.dbo.Tweet (Title, Content, PostedDate, UserId) VALUES ('Title 11', 'Content of Title 11', '2023-01-01', 2);
-- INSERT INTO MyDB.dbo.Tweet (Title, Content, PostedDate, UserId) VALUES ('Title 22', 'Content of Title 22', '2023-01-01', 2);
-- INSERT INTO MyDB.dbo.Tweet (Title, Content, PostedDate, UserId) VALUES ('Title 33', 'Content of Title 33', '2023-01-01', 2);
-- INSERT INTO MyDB.dbo.Tweet (Title, Content, PostedDate, UserId) VALUES ('Title 44', 'Content of Title 44', '2023-01-01', 2);




-- INSERT INTO MyDB.dbo.TweetTags (Tag, TweetId) VALUES ('Tag1', 1);
-- INSERT INTO MyDB.dbo.TweetTags (Tag, TweetId) VALUES ('Tag2', 1);
-- INSERT INTO MyDB.dbo.TweetTags (Tag, TweetId) VALUES ('Tag3', 1);

-- INSERT INTO MyDB.dbo.TweetTags (Tag, TweetId) VALUES ('Tag1', 2);
-- INSERT INTO MyDB.dbo.TweetTags (Tag, TweetId) VALUES ('Tag2', 2);

-- INSERT INTO MyDB.dbo.TweetTags (Tag, TweetId) VALUES ('Tag1', 3);

-- INSERT INTO MyDB.dbo.TweetTags (Tag, TweetId) VALUES ('Tag1', 4);
-- INSERT INTO MyDB.dbo.TweetTags (Tag, TweetId) VALUES ('Tag2', 4);
-- INSERT INTO MyDB.dbo.TweetTags (Tag, TweetId) VALUES ('Tag3', 4);

-- INSERT INTO MyDB.dbo.TweetTags (Tag, TweetId) VALUES ('Tag1', 5);
-- INSERT INTO MyDB.dbo.TweetTags (Tag, TweetId) VALUES ('Tag2', 5);

-- INSERT INTO MyDB.dbo.TweetTags (Tag, TweetId) VALUES ('Tag1', 6);




-- INSERT INTO MyDB.dbo.Comment (Comment, PostedDate, UserId, TweetId) VALUES ('Comment 1 new By User 2', '2023-04-05', 2, 1);
-- INSERT INTO MyDB.dbo.Comment (Comment, PostedDate, UserId, TweetId) VALUES ('Comment 2 By User 2', '2023-04-05', 2, 2);
-- INSERT INTO MyDB.dbo.Comment (Comment, PostedDate, UserId, TweetId) VALUES ('Comment 3 By User 2', '2023-04-05', 2, 3);
-- INSERT INTO MyDB.dbo.Comment (Comment, PostedDate, UserId, TweetId) VALUES ('Comment 4 By User 2', '2023-04-05', 2, 4);

-- INSERT INTO MyDB.dbo.Comment (Comment, PostedDate, UserId, TweetId) VALUES ('Comment 1 By User 1', '2023-04-05', 1, 5);
-- INSERT INTO MyDB.dbo.Comment (Comment, PostedDate, UserId, TweetId) VALUES ('Comment 2 By User 1', '2023-04-05', 1, 6);
-- INSERT INTO MyDB.dbo.Comment (Comment, PostedDate, UserId, TweetId) VALUES ('Comment 3 By User 1', '2023-04-05', 1, 7);
-- INSERT INTO MyDB.dbo.Comment (Comment, PostedDate, UserId, TweetId) VALUES ('Comment 4 By User 1', '2023-04-05', 1, 8);