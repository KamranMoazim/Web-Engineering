using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VehicleLib
{
    public class Vehicle
    {
        public string? type { get; set; }

        public string? model { get; set; }

        public string? licensePlate { get; set; }

        public override string? ToString()
        {
            return $"{type},{model},{licensePlate}";
        }
    }
}